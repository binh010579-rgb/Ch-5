"""TV5: detect fan-out outliers, simulate a plan and compare before/after."""
import path_setup  # noqa: F401
import pandas as pd
import streamlit as st

from backend.services.tree_service import get_valid_tree
from backend.services.recommendation_service import run_recommendation

st.set_page_config(page_title="Đề xuất điều chỉnh", layout="wide")
st.title("5. Đề xuất điều chỉnh cấu trúc chi nhánh (TV5)")
st.write("TV5 dùng cây hợp lệ của TV1 và thống kê fan-out của TV3 để nhận diện nhánh lệch, mô phỏng điều chuyển và kiểm tra kết quả.")

try:
    tree, root, info = get_valid_tree()
except ValueError as exc:
    st.error(f"Chưa có cây hợp lệ: {exc}")
    st.info("Vào trang 1_Data để tạo dữ liệu mẫu hoặc tải CSV trước.")
    st.stop()

k = st.slider(
    "Ngưỡng k: đánh dấu fan-out > trung bình cùng tầng + k × độ lệch chuẩn",
    min_value=0.0, max_value=3.0, value=1.5, step=0.1,
)
st.caption("k là giả định của nhóm để sàng lọc, không phải tiêu chuẩn ngành. Các gợi ý điều chuyển là heuristic; cần xét địa lý và nghiệp vụ trước khi áp dụng.")

try:
    result = run_recommendation(tree, root, threshold=k)
except (ValueError, KeyError) as exc:
    st.error(f"Không thể phân tích cây: {exc}")
    st.stop()

name = lambda node_id: info.get(node_id, {}).get("name", node_id)
st.subheader("Nhánh được đánh dấu")
if result["imbalanced"]:
    flagged_rows = [{
        "Mã đơn vị": row["id"], "Tên đơn vị": name(row["id"]), "Tầng": row["level"],
        "Fan-out": row["fanout"], "Trung bình tầng": round(row["mean"], 2),
        "Độ lệch chuẩn tầng": round(row["std"], 2), "z-score": round(row["z_score"], 2),
        "Lý do": row["reason"],
    } for row in result["imbalanced"]]
    st.dataframe(pd.DataFrame(flagged_rows), use_container_width=True, hide_index=True)
else:
    st.success("Không có đơn vị nào vượt ngưỡng hiện tại.")

st.subheader("Phương án mô phỏng")
st.write(result["plan_note"])
if result["moves"]:
    move_rows = [{
        "Thao tác": move["operation"], "Đơn vị chuyển": name(move["node"]),
        "Mã": move["node"], "Cha cũ": name(move["old_parent"]),
        "Cha mới": name(move["new_parent"]),
    } for move in result["moves"]]
    st.dataframe(pd.DataFrame(move_rows), use_container_width=True, hide_index=True)
else:
    st.info("Không phát sinh điều chuyển. Cây sau mô phỏng giống cây hiện tại.")

st.subheader("Kiểm tra cây và bảo toàn bến xe")
validation = result["validation"]
if validation["ok"]:
    st.success(
        f"Cây hợp lệ; giữ nguyên {validation['station_count_before']} bến xe. "
        "Cây có một gốc, liên thông, không chu trình và mỗi đơn vị khác gốc có đúng một cha."
    )
else:
    st.error("Phương án chưa hợp lệ: " + "; ".join(validation["errors"]))

st.subheader("So sánh trước và sau")
comparison_rows = [{
    **row,
    "Trước": round(row["Trước"], 3) if isinstance(row["Trước"], float) else row["Trước"],
    "Sau": round(row["Sau"], 3) if isinstance(row["Sau"], float) else row["Sau"],
    "Thay đổi": round(row["Thay đổi"], 3) if isinstance(row["Thay đổi"], float) else row["Thay đổi"],
} for row in result["comparison"]["rows"]]
st.dataframe(pd.DataFrame(comparison_rows), use_container_width=True, hide_index=True)
for note in result["comparison"]["notes"]:
    st.write("• " + note)

with st.expander("Xem quy ước và giới hạn"):
    st.markdown(
        "- Tiêu chí: `fan-out > mean_tầng + k × std_tầng` (độ lệch chuẩn tổng thể).\n"
        "- Tự động đề xuất chuyển một phần con sang anh/chị em ít tải nhất cùng cha.\n"
        "- Cây gốc không bị sửa; chỉ bản sao được dùng để mô phỏng.\n"
        "- Fan-out không đo khoảng cách, lượng khách, nhân sự hay chi phí. Đây không phải nghiệm tối ưu toàn cục."
    )
