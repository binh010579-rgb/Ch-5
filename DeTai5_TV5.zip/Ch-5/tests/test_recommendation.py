"""Kiểm thử TV5. Chạy: pytest tests/test_recommendation.py
"""
import copy


from algorithms.rebalance import (
    detect_imbalanced_branches,
    simulate_reorganization,
    validate_reorganization,
)
from backend.services.recommendation_service import run_recommendation
from backend.services.analysis_service import run_analysis


# CN_A có 6 bến, CN_B và CN_C chỉ có 1 bến -> CN_A lệch
LOPSIDED = {
    "ROOT": ["CN_A", "CN_B", "CN_C"],
    "CN_A": ["S1", "S2", "S3", "S4", "S5", "S6"],
    "CN_B": ["S7"],
    "CN_C": ["S8"],
    **{f"S{i}": [] for i in range(1, 9)},
}


def _stations(tree):
    return sorted(n for n, ch in tree.items() if not ch)


def test_no_branch_exceeds_threshold():
    balanced = {"ROOT": ["A", "B"], "A": ["S1", "S2"], "B": ["S3", "S4"],
                **{f"S{i}": [] for i in range(1, 5)}}
    assert detect_imbalanced_branches(balanced, {}, 1.5) == []


def test_only_one_branch_flagged():
    flagged = detect_imbalanced_branches(LOPSIDED, {}, 1.0)
    assert [b["id"] for b in flagged] == ["CN_A"]


def test_simulate_keeps_original_unchanged_and_keeps_stations():
    original = copy.deepcopy(LOPSIDED)
    plan = [{"op": "move", "node": "S6", "new_parent": "CN_B"}]
    new_tree = simulate_reorganization(LOPSIDED, plan)
    assert LOPSIDED == original
    assert _stations(new_tree) == _stations(LOPSIDED)


def test_validate_detects_lost_station():
    bad = copy.deepcopy(LOPSIDED)
    bad["CN_A"].remove("S6")
    del bad["S6"]
    assert validate_reorganization(LOPSIDED, bad)["ok"] is False


def test_validate_detects_duplicate_parent():
    bad = copy.deepcopy(LOPSIDED)
    bad["CN_B"].append("S1")          # S1 có hai cha
    assert validate_reorganization(LOPSIDED, bad)["ok"] is False


def test_validate_detects_cycle():
    bad = copy.deepcopy(LOPSIDED)
    bad["CN_B"].append("CN_A")
    bad["ROOT"].remove("CN_A")
    bad["CN_A"].append("CN_B")        # CN_A <-> CN_B
    assert validate_reorganization(LOPSIDED, bad)["ok"] is False


def test_recommendation_runs_end_to_end_and_reduces_spread():
    result = run_recommendation(LOPSIDED, "ROOT", threshold=1.0)
    assert [row["id"] for row in result["imbalanced"]] == ["CN_A"]
    assert result["validation"]["ok"] is True
    assert result["validation"]["station_count_before"] == 8
    assert result["validation"]["station_count_after"] == 8
    assert result["before"]["fanout"]["overall"]["std"] > result["after"]["fanout"]["overall"]["std"]


def test_recommendation_with_no_outliers_keeps_tree():
    balanced = {"ROOT": ["A", "B"], "A": ["S1", "S2"], "B": ["S3", "S4"],
                **{f"S{i}": [] for i in range(1, 5)}}
    result = run_recommendation(balanced, "ROOT", threshold=1.5)
    assert result["imbalanced"] == []
    assert result["plan"] == []
    assert result["new_tree"] == balanced


def test_split_and_merge_preserve_station_leaves():
    tree = {"ROOT": ["A", "B"], "A": ["S1", "S2"], "B": ["S3"],
            "S1": [], "S2": [], "S3": []}
    split = simulate_reorganization(tree, [{"op": "split", "node": "A",
                                           "new_node": "A2", "move_children": ["S2"]}])
    assert validate_reorganization(tree, split)["ok"] is True
    merged = simulate_reorganization(split, [{"op": "merge", "node": "A2", "into": "A"}])
    assert validate_reorganization(split, merged)["ok"] is True
    assert _stations(merged) == _stations(tree)


def test_transfer_can_increase_depth_and_report_it():
    tree = {"ROOT": ["A", "B"], "A": ["A1"], "A1": ["S1"], "S1": [],
            "B": ["B1"], "B1": ["B2"], "B2": ["S2"], "S2": []}
    moved = simulate_reorganization(tree, [{"op": "move", "node": "A", "new_parent": "B2"}])
    assert validate_reorganization(tree, moved)["ok"] is True
    assert run_analysis(moved, "ROOT")["height"] > run_analysis(tree, "ROOT")["height"]


def test_official_csv_dataset_has_61_stations_and_an_actionable_result():
    import csv
    from pathlib import Path
    from algorithms.tree import build_tree

    project_root = Path(__file__).resolve().parents[1]
    with (project_root / "data" / "organization.csv").open(encoding="utf-8", newline="") as f:
        records = list(csv.DictReader(f))
    tree, _, root = build_tree(records)
    result = run_recommendation(tree, root, threshold=1.5)
    assert result["before"]["structure"]["total_leaves"] == 61
    assert result["before"]["structure"]["height"] == 3
    assert [row["id"] for row in result["imbalanced"]] == ["CN_MN_HCM"]
    assert result["validation"]["ok"] is True
    assert result["after"]["structure"]["total_leaves"] == 61
    assert result["after"]["structure"]["height"] == 3
    assert result["after"]["fanout"]["overall"]["std"] < result["before"]["fanout"]["overall"]["std"]
