# TV5 - Kết quả và nhận xét trên dữ liệu mẫu

## Tiêu chí phát hiện

Fan-out là số đơn vị con trực tiếp. TV5 so sánh các đơn vị quản lý ở cùng tầng và đánh dấu khi:

`fan-out > trung bình tầng + k × độ lệch chuẩn tầng`

Dùng `k = 1.5` làm giá trị mặc định minh họa. Đây là ngưỡng heuristic do nhóm chọn, không phải tiêu chuẩn ngành.

## Số liệu và phương án

`data/organization.csv` có 75 đơn vị, 14 đỉnh trong, 61 bến xe và độ sâu lớn nhất 3. Ở tầng 2 có 9 đơn vị quản lý; fan-out trung bình là 6.56, độ lệch chuẩn 4.25, nên ngưỡng với k = 1.5 là khoảng 12.92. `CN_MN_HCM` có fan-out 15 và được đánh dấu.

Mô phỏng chuyển sáu bến `BX_MN_HCM_10` đến `BX_MN_HCM_15` từ `CN_MN_HCM` sang `CN_MN_DNA`, một đơn vị anh/chị em cùng trực thuộc `CN_MN`. Phân bổ ba chi nhánh cấp khu vực thay đổi từ 15–5–2 thành 9–5–8. Phương án được tạo trên bản sao; dữ liệu gốc không đổi.

| Chỉ số | Trước | Sau | Thay đổi |
| --- | ---: | ---: | ---: |
| Tổng đơn vị | 75 | 75 | 0 |
| Đỉnh trong | 14 | 14 | 0 |
| Bến xe (lá) | 61 | 61 | 0 |
| Độ sâu lớn nhất | 3 | 3 | 0 |
| Độ lệch chuẩn fan-out toàn cây | 3.862 | 2.986 | -0.876 |
| Độ lệch chuẩn fan-out tầng 2 | 4.246 | 2.948 | -1.297 |
| Fan-out lớn nhất tầng 2 | 15 | 12 | -3 |

Cây sau mô phỏng vẫn có một gốc, liên thông, không chu trình, mỗi đỉnh ngoài gốc có đúng một cha và giữ nguyên danh sách 61 bến.

## Nhận xét và đánh đổi

Độ lệch fan-out giảm và độ sâu không đổi, nên phương án cải thiện mức phân bổ theo chỉ số đang dùng mà không thêm tầng trong ví dụ. Đây vẫn chỉ là mô phỏng. Fan-out không cho biết khoảng cách địa lý, lượng hành khách, nhân lực hay chi phí vận hành. Trước khi đề xuất tái cơ cấu thực tế, cần xác nhận việc chuyển bến giữa các đơn vị phù hợp về địa bàn và trách nhiệm quản lý. Không thể kết luận đây là phương án tối ưu toàn cục.

## Cách kiểm tra

Có thể chạy `pytest tests/test_recommendation.py -q` ở thư mục gốc. Bộ trường hợp kiểm tra gồm: không có nhánh vượt ngưỡng, một nhánh vượt ngưỡng, cây gốc không bị sửa, mất bến, trùng cha, chu trình, luồng service trước-sau, tách/gộp và tăng số tầng.
