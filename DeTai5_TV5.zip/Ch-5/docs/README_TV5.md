# TV5 - Phát hiện fan-out lệch và đề xuất điều chỉnh

## File TV5

| File | Vai trò |
| --- | --- |
| `algorithms/rebalance.py` | Tính ngưỡng theo tầng, mô phỏng chuyển/tách/gộp trên bản sao, kiểm tra cây và bến xe |
| `backend/services/recommendation_service.py` | Nhận cây TV1, dùng phân tích TV2/TV3, tạo phương án và bảng trước-sau |
| `frontend/pages/5_Recommendation.py` | Giao diện hiển thị nhánh bị đánh dấu, cha cũ/mới, kiểm tra và kết quả |
| `tests/test_recommendation.py` | Các trường hợp lệch/không lệch, chuyển đơn vị, bảo toàn bến, cây sai, tách/gộp và tăng tầng |
| `docs/TV5_ket_qua_va_nhan_xet.md` | Kết quả mẫu trên `data/organization.csv` và giới hạn diễn giải |

## Chạy trong repository

Từ thư mục gốc `Ch-5`:

```bash
pip install -r requirements.txt
streamlit run frontend/app.py
pytest tests/test_recommendation.py -q
```

Vào trang **5. Đề xuất điều chỉnh cấu trúc chi nhánh (TV5)**. Trước đó cần vào trang 1 và nạp dữ liệu hợp lệ. Trang lấy cây qua `get_valid_tree()` của TV1; không đọc database trực tiếp. Thống kê được tạo từ `run_fanout_analysis()` của TV3, đúng các khóa `fanout` và `by_level` mà repo đã thống nhất.

## Tiêu chí và giao tiếp

Một đơn vị bị đánh dấu khi `fan-out > mean_tầng + k × std_tầng`. Dùng độ lệch chuẩn tổng thể giống module TV3. `k` do nhóm chọn; đây là heuristic sàng lọc, không phải tiêu chuẩn ngành.

Nếu không truyền `plan`, service đề xuất chuyển một phần đơn vị con sang đơn vị anh/chị em ít tải nhất cùng cha. Có thể truyền kế hoạch cụ thể vào `run_recommendation(tree, root, threshold, plan)`:

```python
plan = [{"op": "move", "node": "BX_01", "new_parent": "CN_B"}]
```

Thuật toán cũng hỗ trợ `split` và `merge`. Cây gốc không bị sửa. Phương án chỉ được chấp nhận nếu cây mới có một gốc, liên thông, không chu trình, mỗi đơn vị ngoài gốc có đúng một cha và tập lá/bến xe được bảo toàn.

Kết quả service gồm `imbalanced`, `plan`, `moves`, `validation`, `before`, `after` và `comparison`. Các report `before`/`after` ghép báo cáo cấu trúc TV2 với báo cáo fan-out TV3.

## Độ phức tạp

Phát hiện, kiểm tra cây, tính độ sâu và thống kê chạy `O(V+E)` thời gian; với cây `E=V−1` nên là `O(V)`. Sao chép cây dùng `O(V+E)` bộ nhớ. Mỗi thao tác chuyển tìm cha bằng quét danh sách kề nên M thao tác tốn tối đa `O(M(V+E))` trong cài đặt này.
