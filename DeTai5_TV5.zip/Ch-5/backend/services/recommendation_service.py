"""TV5 service integrating TV1 tree, TV2 structure and TV3 fan-out analysis."""
from algorithms.rebalance import (
    detect_imbalanced_branches,
    evaluate_before_after,
    simulate_reorganization,
    validate_reorganization,
)
from backend.services.analysis_service import run_analysis
from backend.services.statistics_service import run_fanout_analysis


def run_recommendation(tree, root, threshold=1.5, plan=None):
    """Detect, simulate, validate and compare before/after.

    If no explicit plan is given, move half the child-count difference from a
    flagged node to its least-loaded sibling under the same parent. This simple
    heuristic is disclosed in the returned result and may be replaced by an
    operator-provided plan.
    """
    old_fanout = run_fanout_analysis(tree, root)
    old_structure = run_analysis(tree, root)
    imbalanced = detect_imbalanced_branches(tree, old_fanout, threshold)
    generated_plan = plan is None
    if plan is None:
        plan = _suggest_moves(tree, imbalanced)
    new_tree = simulate_reorganization(tree, plan)
    validation = validate_reorganization(tree, new_tree)
    new_fanout = run_fanout_analysis(new_tree, root)
    new_structure = run_analysis(new_tree, root)
    before = {"structure": old_structure, "fanout": old_fanout}
    after = {"structure": new_structure, "fanout": new_fanout}
    comparison = evaluate_before_after(before, after)
    parent_map_before = {node: _find_parent(tree, node) for node in tree}
    parent_map_after = {node: _find_parent(new_tree, node) for node in new_tree}
    moves = []
    for item in plan:
        node = item.get("node", item.get("node_id"))
        moves.append({"operation": item.get("op", "move"), "node": node,
                      "old_parent": parent_map_before.get(node),
                      "new_parent": parent_map_after.get(node), "details": item})
    return {
        "imbalanced": imbalanced, "plan": plan, "moves": moves,
        "plan_generated": generated_plan,
        "plan_note": ("Tự đề xuất điều chuyển một phần các đơn vị con sang anh/chị em ít tải nhất cùng cha. "
                      "Cần kiểm tra điều kiện địa lý và nghiệp vụ trước khi áp dụng." if generated_plan
                      else "Phương án do người dùng cung cấp."),
        "new_tree": new_tree, "validation": validation,
        "before": before, "after": after, "comparison": comparison,
    }


def _suggest_moves(tree, flags):
    parent = {child: node for node, children in tree.items() for child in children}
    fanout = {node: len(children) for node, children in tree.items() if children}
    plan = []
    for flag in flags:
        source = flag["id"]
        source_parent = parent.get(source)
        if source_parent is None or fanout.get(source, 0) < 2:
            continue
        siblings = [node for node in tree[source_parent]
                    if node != source and tree.get(node) and fanout.get(node, 0) < fanout[source]]
        if not siblings:
            continue
        target = min(siblings, key=lambda node: (fanout[node], node))
        move_count = (fanout[source] - fanout[target]) // 2
        if move_count <= 0:
            continue
        children = list(tree[source])[-move_count:]
        plan.extend({"op": "move", "node": child, "new_parent": target} for child in children)
        # Keep the next candidate calculations aligned with the already proposed moves.
        fanout[source] -= move_count
        fanout[target] += move_count
    return plan


def _find_parent(tree, node):
    return next((parent for parent, children in tree.items() if node in children), None)
