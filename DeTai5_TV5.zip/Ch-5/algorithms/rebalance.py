"""TV5: detect fan-out imbalance and simulate tree reorganization.

Tree format follows TV1: ``tree[node_id] = [child_id, ...]``. Operations run on a
copy and are heuristic simulations, not claims of a globally optimal structure.
"""
from collections import deque
from copy import deepcopy
from math import sqrt


def _root_and_depths(tree):
    if not tree:
        raise ValueError("Cây rỗng")
    parents = {node: 0 for node in tree}
    for parent, children in tree.items():
        if not isinstance(children, list):
            raise ValueError(f"Danh sách con của {parent} không hợp lệ")
        for child in children:
            if child not in tree:
                raise ValueError(f"Không tìm thấy đỉnh con {child}")
            parents[child] += 1
    roots = [node for node, count in parents.items() if count == 0]
    if len(roots) != 1:
        raise ValueError(f"Cây phải có đúng một gốc, tìm thấy {len(roots)}")
    root = roots[0]
    depths = {root: 0}
    queue = deque([root])
    while queue:
        node = queue.popleft()
        for child in tree[node]:
            if child in depths:
                raise ValueError(f"Phát hiện chu trình hoặc nhiều cha tại {child}")
            depths[child] = depths[node] + 1
            queue.append(child)
    if len(depths) != len(tree):
        raise ValueError("Cây không liên thông: có đỉnh không đi tới được từ gốc")
    if any(count != 1 for node, count in parents.items() if node != root):
        raise ValueError("Mỗi đỉnh khác gốc phải có đúng một cha")
    return root, depths


def _fanout_report_from_tree(tree):
    _, depths = _root_and_depths(tree)
    by_level = {}
    fanout = {node: len(children) for node, children in tree.items() if children}
    for node, count in fanout.items():
        by_level.setdefault(depths[node], []).append(count)
    report = {"fanout": fanout, "by_level": []}
    for level, values in sorted(by_level.items()):
        mean = sum(values) / len(values)
        variance = sum((value - mean) ** 2 for value in values) / len(values)
        report["by_level"].append({"level": level, "count": len(values), "mean": mean,
                                   "std": sqrt(variance), "min": min(values), "max": max(values)})
    return report, depths


def detect_imbalanced_branches(tree, fanout_report, threshold):
    """Flag internal nodes where fan-out > level mean + k * level population std.

    ``threshold`` is the group's k assumption; it is not an industry standard.
    The TV3 report shape is ``{"fanout": {...}, "by_level": [{level, mean, std}, ...]}``.
    Missing level statistics are recalculated from the tree.
    """
    if threshold < 0:
        raise ValueError("Ngưỡng k phải >= 0")
    calculated, depths = _fanout_report_from_tree(tree)
    report = fanout_report or calculated
    supplied = {row["level"]: row for row in report.get("by_level", [])}
    fanout = report.get("fanout") or calculated["fanout"]
    flags = []
    for node, count in fanout.items():
        if node not in tree or not tree[node]:
            continue
        level = depths[node]
        stats = supplied.get(level)
        if stats is None:
            stats = next(row for row in calculated["by_level"] if row["level"] == level)
        mean, std = float(stats["mean"]), float(stats["std"])
        limit = mean + threshold * std
        if count > limit:
            z_score = (count - mean) / std if std else float("inf")
            flags.append({
                "id": node, "level": level, "fanout": count, "mean": mean,
                "std": std, "z_score": z_score, "limit": limit,
                "reason": f"Fan-out {count} > {mean:.2f} + {threshold:g} × {std:.2f} = {limit:.2f}",
            })
    return sorted(flags, key=lambda row: (-row["fanout"], row["id"]))


def simulate_reorganization(tree, plan):
    """Apply move/split/merge operations to a deep copy of ``tree``.

    move:  {"op":"move", "node":"BX_1", "new_parent":"CN_B"}
    split: {"op":"split", "node":"CN_A", "new_node":"CN_A2", "move_children":[...]}
    merge: {"op":"merge", "node":"CN_B", "into":"CN_A"}
    """
    _root_and_depths(tree)
    result = deepcopy(tree)
    if plan is None:
        plan = []
    if isinstance(plan, dict):
        plan = plan.get("moves", [plan])
    if not plan:
        return result
    for operation in plan:
        op = operation.get("op", "move")
        if op == "move":
            node = operation.get("node", operation.get("node_id"))
            new_parent = operation.get("new_parent", operation.get("new_parent_id"))
            parent = _parent_of(result, node)
            if node is None or new_parent not in result or parent is None:
                raise ValueError(f"Không tìm thấy đơn vị cần chuyển hoặc cha mới: {node} -> {new_parent}")
            if node == new_parent or new_parent in _descendants(result, node):
                raise ValueError("Phương án chuyển sẽ tạo chu trình")
            if parent == new_parent:
                raise ValueError(f"{node} đã trực thuộc {new_parent}")
            result[parent].remove(node)
            result[new_parent].append(node)
        elif op == "split":
            node, new_node = operation.get("node"), operation.get("new_node")
            moved = operation.get("move_children", [])
            if node not in result or not new_node or new_node in result or not moved:
                raise ValueError("Thao tác tách cần node, mã new_node chưa tồn tại và danh sách con cần chuyển")
            if any(child not in result[node] for child in moved):
                raise ValueError("Mọi đơn vị được chuyển khi tách phải là con trực tiếp của node")
            result[new_node] = list(moved)
            result[node] = [child for child in result[node] if child not in set(moved)] + [new_node]
        elif op == "merge":
            node, target = operation.get("node"), operation.get("into")
            parent = _parent_of(result, node)
            if node not in result or target not in result or node == target or parent is None:
                raise ValueError("Thao tác gộp không hợp lệ")
            if target in _descendants(result, node):
                raise ValueError("Không thể gộp vào đỉnh con của chính node")
            children = result[node]
            result[parent].remove(node)
            if target == parent:
                result[parent].extend(children)
            else:
                result[target].extend(children)
            del result[node]
        else:
            raise ValueError(f"Loại thao tác chưa hỗ trợ: {op}")
    validation = validate_reorganization(tree, result)
    if not validation["ok"]:
        raise ValueError("Phương án không hợp lệ: " + "; ".join(validation["errors"]))
    return result


def validate_reorganization(old_tree, new_tree):
    """Validate tree properties and preserve the exact station/leaf set."""
    errors = []
    for label, tree in (("Cây trước", old_tree), ("Cây sau", new_tree)):
        try:
            _root_and_depths(tree)
        except (ValueError, TypeError) as exc:
            errors.append(f"{label}: {exc}")
    old_leaves = {node for node, children in old_tree.items() if not children}
    new_leaves = {node for node, children in new_tree.items() if not children}
    if len(old_leaves) != len(new_leaves):
        errors.append(f"Số bến xe thay đổi: {len(old_leaves)} -> {len(new_leaves)}")
    if old_leaves != new_leaves:
        errors.append("Tập bến xe (các đỉnh lá) bị mất hoặc thay đổi")
    return {"ok": not errors, "errors": errors,
            "station_count_before": len(old_leaves), "station_count_after": len(new_leaves),
            "preserves_stations": old_leaves == new_leaves}


def evaluate_before_after(old_report, new_report):
    """Return scan-friendly comparison rows and trade-off notes.

    Reports use a bundle with ``structure`` (TV2) and ``fanout`` (TV3).
    """
    old_s, new_s = old_report["structure"], new_report["structure"]
    old_f, new_f = old_report["fanout"], new_report["fanout"]
    rows = [
        {"Chỉ số": "Số đơn vị |V|", "Trước": old_s["total_nodes"], "Sau": new_s["total_nodes"]},
        {"Chỉ số": "Số đỉnh trong I", "Trước": old_s["total_internal"], "Sau": new_s["total_internal"]},
        {"Chỉ số": "Số bến xe L", "Trước": old_s["total_leaves"], "Sau": new_s["total_leaves"]},
        {"Chỉ số": "Số tầng (độ sâu lớn nhất)", "Trước": old_s["height"], "Sau": new_s["height"]},
        {"Chỉ số": "Độ lệch chuẩn fan-out toàn cây", "Trước": old_f["overall"]["std"], "Sau": new_f["overall"]["std"]},
    ]
    for row in rows:
        row["Thay đổi"] = row["Sau"] - row["Trước"]
    notes = []
    before_std, after_std = old_f["overall"]["std"], new_f["overall"]["std"]
    if after_std < before_std:
        notes.append("Độ lệch chuẩn fan-out toàn cây giảm.")
    elif after_std > before_std:
        notes.append("Độ lệch chuẩn fan-out toàn cây tăng.")
    else:
        notes.append("Độ lệch chuẩn fan-out toàn cây không đổi.")
    if new_s["height"] > old_s["height"]:
        notes.append("Số tầng tăng, cấu trúc quản lý sâu hơn.")
    elif new_s["height"] < old_s["height"]:
        notes.append("Số tầng giảm.")
    else:
        notes.append("Số tầng không đổi.")
    notes.append("Đây là heuristic theo tiêu chí nhóm, không phải phương án tối ưu toàn cục.")
    return {"rows": rows, "notes": notes}


def _parent_of(tree, child):
    if child is None:
        return None
    return next((parent for parent, children in tree.items() if child in children), None)


def _descendants(tree, node):
    result, stack = set(), list(tree.get(node, []))
    while stack:
        current = stack.pop()
        if current not in result:
            result.add(current)
            stack.extend(tree.get(current, []))
    return result
